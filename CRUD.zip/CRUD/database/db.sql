-- create te database --

-- used the database --
use usuarios;

--create table--
create TABLE peliculas(
    id int(6) unsigned AUTO_INCREMENT PRIMARY KEY,
    name VARCHAr(50) NOT NULL,
    address  VARCHAr(100) NOT NULL,
    phone  VARCHAr(50) NOT NULL,
);

--mostrar TABLES
SHOW TABLES;

--descripcion
DESCRIBE peliculas;
