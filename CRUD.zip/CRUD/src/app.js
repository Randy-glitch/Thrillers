const express = require('express');
const morgan = require('morgan');
const mysql = require('mysql');
const myConnection = require('express-myconnection');

const path = require('path');
const app = express();


//import rutas
const customerRoutes = require('./router/customers');


//setting
app.set('port', process.env.PORT || 3000);
app.set('view engine', 'ejs');
app.set('view ', path.join(__dirname, 'views'));

//middleware // DB
app.use(morgan('dev'));
app.use(myConnection(mysql, {
    host: 'localhost',
    user: 'randy',
    password: 'randy',
    port: 3306,
    database: 'usuarios'
}, "single"));
app.use(express.urlencoded({extended: false}));


//Rutas
app.use('/', customerRoutes);

//static File
app.use(express.static(path.join(__dirname, 'public')));



//empezando el servidor
app.listen(app.get('port'), ()=>{
    console.log('Server in port:'+ app.get('port'))
});