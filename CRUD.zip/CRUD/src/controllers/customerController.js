const controller = {};



controller.lis = (req, res) =>{
    req.getConnection((err, conn) =>{
        conn.query('SELECT * FROM hola', (err,customers)=>{
            if(err){
                res.json(err);
            }
            res.render('C:\\Users\\l4ur3\\OneDrive\\Escritorio\\CRUD\\src\\views\\customers.ejs', {
                data: customers
            });
            
        });
    });
};

controller.save = (req,res)=>{
    const data = req.body;
    var sql = "INSERT IGNORE `hola` set ?";
    req.getConnection((err, conn)=>{
        if (err) throw err;
        conn.query(sql, [data], (err, rows)=>{
            if(err) throw err;
            
        })
        res.redirect('/');
    })
    
}

controller.edit = (req,res)=>{
    const id = req.params.id;

    req.getConnection((err, conn)=>{

        conn.query('SELECT * FROM `hola` WHERE `id` = ?', [id], (err, rows)=>{
            if (err) throw err;
            res.render('C:\\Users\\l4ur3\\OneDrive\\Escritorio\\CRUD\\src\\views\\partials\\customersEdit.ejs', {
                data: rows[0]
            });
        })
    })
    
}
controller.update = (req,res)=>{
    
    const id = parseInt(req.params.id) ;
    const newCustomers = req.body;
    req.getConnection((err, conn)=>{

        conn.query('UPDATE `hola` SET ? WHERE id = ?', [newCustomers,id], (err, rows)=>{
            if (err) throw err;
            res.redirect('/');
            });
        });  
};

controller.ver = (req,res)=>{
    req.getConnection((err, conn) =>{
        conn.query('SELECT * FROM hola', (err,customers)=>{
            if(err){
                res.json(err);
            }
            res.render('C:\\Users\\l4ur3\\OneDrive\\Escritorio\\CRUD\\src\\views\\ver.ejs', {
                data: customers
            });
        });
    });
}

controller.login = (req,res)=>{
    req.getConnection((err, conn) =>{
        conn.query('SELECT * FROM admin', (err,customers)=>{
            if (err) throw err;
            res.render('C:\\Users\\l4ur3\\OneDrive\\Escritorio\\CRUD\\src\\views\\login.ejs',{
                lg: customers
            });
            
        })
    })
}

controller.delete = (req,res)=>{
    const id = req.params.id;
    req.getConnection((err, conn)=>{
        
        conn.query('DELETE FROM `hola` WHERE `hola`.`id` = ?', [id], (err, rows)=>{
            res.redirect('/');
        })
    })
    
}

module.exports = controller;