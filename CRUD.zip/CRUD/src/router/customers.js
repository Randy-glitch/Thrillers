const express = require('express');
const router = express.Router();

const customerController = require('../controllers/customerController')


router.get('/', customerController.lis);
router.post('/add', customerController.save);
router.get('/delete/:id', customerController.delete);
router.get('/update/:id', customerController.edit);
router.post('/update/:id', customerController.update);
router.get('/ver', customerController.ver);
router.get('/login', customerController.login);

module.exports = router;